// app/api/knowledge/route.ts
import { NextRequest, NextResponse } from "next/server";
import { callClaude } from "@/lib/claude";
import { repairJson } from "@/lib/repairJson";
import { KNOWLEDGE_SYSTEM_PROMPT } from "@/lib/prompts";
import type { ParsedRecipe, Knowledge, ApiResponse } from "@/types";

const FALLBACK_WORKFLOW = (duration: number): Knowledge => ({
  tips: [],
  warnings: [],
  workflow: [
    { phase: "Mise en place", tasks: ["재료를 꺼내 한곳에 모읍니다", "도구를 준비합니다"], timerMin: null },
    { phase: "계량", tasks: ["모든 재료를 정확히 계량합니다"], timerMin: null },
    { phase: "반죽", tasks: ["레시피 순서대로 재료를 혼합합니다"], timerMin: null },
    { phase: "굽기", tasks: ["예열된 오븐에 굽습니다"], timerMin: duration },
    { phase: "식힘 & 마무리", tasks: ["완전히 식힌 후 마무리합니다"], timerMin: null },
  ],
});

export async function POST(req: NextRequest) {
  const MAX_RETRY = 2;

  try {
    const { recipe } = await req.json() as { recipe: ParsedRecipe };
    if (!recipe?.name) {
      return NextResponse.json(
        { error: "recipe 필드가 필요합니다." } satisfies ApiResponse<never>,
        { status: 400 }
      );
    }

    const ingredientList = recipe.ingredients?.length
      ? recipe.ingredients.map((i) => i.name).join(", ")
      : "재료 정보 없음";

    const userContent = `레시피:${recipe.name}(${recipe.category ?? "제과"}) 오븐:${recipe.oven?.temp ?? 180}°C ${recipe.oven?.duration ?? 15}분 재료:${ingredientList}`;

    let lastResult = null;
    let knowledge: Knowledge | null = null;

    // 최대 MAX_RETRY 회 시도
    for (let attempt = 0; attempt <= MAX_RETRY; attempt++) {
      const result = await callClaude(userContent, KNOWLEDGE_SYSTEM_PROMPT, 4096);
      lastResult = result;

      if (result.truncated && attempt < MAX_RETRY) continue; // 재시도

      try {
        const repaired = repairJson(result.text);
        const data = JSON.parse(repaired) as Knowledge;
        if (!Array.isArray(data.tips)) data.tips = [];
        if (!Array.isArray(data.warnings)) data.warnings = [];
        if (!Array.isArray(data.workflow) || data.workflow.length === 0) {
          data.workflow = FALLBACK_WORKFLOW(recipe.oven?.duration ?? 15).workflow;
        }
        knowledge = data;
        break;
      } catch {
        if (attempt === MAX_RETRY) {
          // 모든 시도 실패 → fallback
          knowledge = FALLBACK_WORKFLOW(recipe.oven?.duration ?? 15);
        }
        // 파싱 실패도 재시도
      }
    }

    return NextResponse.json({
      data: knowledge,
      truncated: lastResult?.truncated ?? false,
      usage: lastResult?.usage,
    } satisfies ApiResponse<Knowledge>);
  } catch (e) {
    const msg = e instanceof Error ? e.message : "서버 오류";
    return NextResponse.json(
      { error: msg } satisfies ApiResponse<never>,
      { status: 500 }
    );
  }
}
